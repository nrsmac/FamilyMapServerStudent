package Services;

public interface IService {

}
