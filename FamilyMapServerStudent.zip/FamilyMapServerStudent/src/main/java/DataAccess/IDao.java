package DataAccess;

/**
 * Represents a dao object
 */
public interface IDao {
    String username = null;
    default void sync() {

    }
}
