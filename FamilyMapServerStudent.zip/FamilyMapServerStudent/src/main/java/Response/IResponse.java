package Response;

public interface IResponse {
}
