package Request;

public interface IRequest { }
