package Handlers;

public interface IHandler {
}
