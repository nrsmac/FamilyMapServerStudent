/**
 * The main driver for the FamilyMap API and web server.
 */

public class Server {
    /**
     * Runs the family map server
     * @param args command-line arguments
     * accepts a port number between 1-65535 as an argument.
     * The default port is 8080.
     */
    public static void main(String[] args) {

    }
}
